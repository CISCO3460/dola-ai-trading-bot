from datetime import datetime, timezone
import math
import time
from collections import defaultdict

from broker import AlpacaBroker
from config import settings
from strategy import AIModel

class TradingEngine:
    def __init__(self, broker=None):
        self.broker = broker or AlpacaBroker()
        self.models = defaultdict(AIModel)
        self.last_trade = {}

    def equity(self):
        return float(self.broker.account().equity)

    def risk_ok(self):
        account = self.broker.account()
        equity = float(account.equity)
        last_equity = float(account.last_equity)
        if last_equity <= 0:
            return True
        daily_change = (equity - last_equity) / last_equity
        return daily_change > -settings.max_daily_loss_pct

    def quantity_for(self, price):
        equity = self.equity()
        risk_budget = equity * settings.risk_per_trade
        stop_distance = price * settings.stop_loss_pct
        if stop_distance <= 0:
            return 0.0

        qty_by_risk = risk_budget / stop_distance
        qty_by_cap = (equity * settings.max_position_pct) / price
        qty = min(qty_by_risk, qty_by_cap)
        return max(0.0, math.floor(qty * 100) / 100)

    def analyze(self, symbol):
        bars = self.broker.bars(symbol)
        if bars.empty or len(bars) < 100:
            return {"symbol": symbol, "signal": "HOLD", "prob_up": 0.5, "price": None}

        model = self.models[symbol]
        model.fit(bars)
        result = model.predict(bars)
        result.update({
            "symbol": symbol,
            "price": float(bars["close"].iloc[-1]),
            "timestamp": bars.index[-1],
        })
        return result

    def evaluate_and_trade(self, symbol, force=False):
        result = self.analyze(symbol)
        if result.get("price") is None:
            result["action"] = "NO_DATA"
            return result
        if not self.broker.is_market_open():
            result["action"] = "MARKET_CLOSED"
            return result
        if not self.risk_ok():
            result["action"] = "DAILY_RISK_LIMIT"
            return result

        now = datetime.now(timezone.utc)
        last = self.last_trade.get(symbol)
        if (
            not force and last and
            (now - last).total_seconds() < settings.trade_cooldown_minutes * 60
        ):
            result["action"] = "COOLDOWN"
            return result

        position = self.broker.position_for(symbol)
        signal = result["signal"]
        prob = result["prob_up"]

        if signal == "BUY" and prob >= settings.min_signal_prob and position is None:
            qty = self.quantity_for(result["price"])
            if qty > 0:
                order = self.broker.submit_bracket_buy(symbol, qty, result["price"])
                self.last_trade[symbol] = now
                result["action"] = f"BUY {qty:g}"
                result["order_id"] = str(order.id)
            else:
                result["action"] = "POSITION_TOO_SMALL"
        elif signal == "SELL" and position is not None:
            order = self.broker.close_position(symbol)
            self.last_trade[symbol] = now
            result["action"] = "CLOSE"
            result["order_id"] = str(order.id) if hasattr(order, "id") else ""
        else:
            result["action"] = "HOLD"

        return result

    def run_once(self):
        results = []
        for symbol in settings.symbols:
            try:
                results.append(self.evaluate_and_trade(symbol))
            except Exception as exc:
                results.append({"symbol": symbol, "signal": "ERROR", "action": str(exc)})
        return results

    def run_forever(self):
        while True:
            self.run_once()
            time.sleep(settings.bot_interval_seconds)
