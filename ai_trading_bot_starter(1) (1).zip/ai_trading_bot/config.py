import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

def _bool(name, default):
    return os.getenv(name, str(default)).strip().lower() in {"1", "true", "yes", "on"}

def _float(name, default):
    return float(os.getenv(name, default))

def _int(name, default):
    return int(os.getenv(name, default))

@dataclass(frozen=True)
class Settings:
    api_key: str = os.getenv("ALPACA_API_KEY", "")
    secret_key: str = os.getenv("ALPACA_SECRET_KEY", "")
    paper_trade: bool = _bool("ALPACA_PAPER_TRADE", True)
    symbols: tuple = tuple(
        s.strip().upper() for s in os.getenv("SYMBOLS", "SPY,QQQ,AAPL,MSFT,NVDA").split(",")
        if s.strip()
    )
    timeframe_minutes: int = _int("TIMEFRAME_MINUTES", 5)
    lookback_bars: int = _int("LOOKBACK_BARS", 500)
    risk_per_trade: float = _float("RISK_PER_TRADE", 0.005)
    max_position_pct: float = _float("MAX_POSITION_PCT", 0.20)
    max_daily_loss_pct: float = _float("MAX_DAILY_LOSS_PCT", 0.02)
    stop_loss_pct: float = _float("STOP_LOSS_PCT", 0.01)
    take_profit_pct: float = _float("TAKE_PROFIT_PCT", 0.02)
    min_signal_prob: float = _float("MIN_SIGNAL_PROB", 0.60)
    bot_interval_seconds: int = _int("BOT_INTERVAL_SECONDS", 60)
    trade_cooldown_minutes: int = _int("TRADE_COOLDOWN_MINUTES", 30)

settings = Settings()
