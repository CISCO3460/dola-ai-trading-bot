import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

FEATURES = [
    "ret_1", "ret_3", "ret_10", "rsi", "macd", "macd_signal",
    "ema_fast_ratio", "ema_slow_ratio", "volatility", "volume_ratio",
]

def add_features(df):
    x = df.copy()
    close = x["close"].astype(float)
    volume = x["volume"].astype(float)

    x["ret_1"] = close.pct_change(1)
    x["ret_3"] = close.pct_change(3)
    x["ret_10"] = close.pct_change(10)

    delta = close.diff()
    gain = delta.clip(lower=0).rolling(14).mean()
    loss = (-delta.clip(upper=0)).rolling(14).mean()
    rs = gain / loss.replace(0, np.nan)
    x["rsi"] = (100 - (100 / (1 + rs))) / 100

    ema12 = close.ewm(span=12, adjust=False).mean()
    ema26 = close.ewm(span=26, adjust=False).mean()
    x["macd"] = ema12 - ema26
    x["macd_signal"] = x["macd"].ewm(span=9, adjust=False).mean()

    ema20 = close.ewm(span=20, adjust=False).mean()
    ema50 = close.ewm(span=50, adjust=False).mean()
    x["ema_fast_ratio"] = close / ema20 - 1
    x["ema_slow_ratio"] = close / ema50 - 1
    x["volatility"] = x["ret_1"].rolling(20).std()
    x["volume_ratio"] = volume / volume.rolling(20).mean()

    return x.replace([np.inf, -np.inf], np.nan)

class AIModel:
    # Transparent baseline: predicts probability that the next bar closes higher.
    def __init__(self):
        self.model = Pipeline([
            ("scale", StandardScaler()),
            ("clf", LogisticRegression(max_iter=1000, class_weight="balanced")),
        ])
        self.ready = False

    def fit(self, bars):
        x = add_features(bars)
        x["target"] = (x["close"].shift(-1) > x["close"]).astype(int)
        train = x.dropna(subset=FEATURES + ["target"]).iloc[:-1]

        if len(train) < 100 or train["target"].nunique() < 2:
            self.ready = False
            return

        self.model.fit(train[FEATURES], train["target"])
        self.ready = True

    def predict(self, bars):
        x = add_features(bars)
        row = x.dropna(subset=FEATURES).iloc[-1:]

        if row.empty or not self.ready:
            return {"signal": "HOLD", "prob_up": 0.5, "confidence": 0.0}

        prob = float(self.model.predict_proba(row[FEATURES])[0, 1])
        if prob >= 0.60:
            signal = "BUY"
        elif prob <= 0.40:
            signal = "SELL"
        else:
            signal = "HOLD"

        return {
            "signal": signal,
            "prob_up": prob,
            "confidence": abs(prob - 0.5) * 2,
            "rsi": float(row["rsi"].iloc[0]),
            "volatility": float(row["volatility"].iloc[0]),
        }
