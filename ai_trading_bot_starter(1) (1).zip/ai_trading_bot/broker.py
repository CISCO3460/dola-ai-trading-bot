from datetime import datetime, timedelta, timezone
import pandas as pd

from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest
from alpaca.data.timeframe import TimeFrame, TimeFrameUnit
from alpaca.data.enums import DataFeed
from alpaca.trading.client import TradingClient
from alpaca.trading.enums import OrderSide, TimeInForce, OrderType
from alpaca.trading.requests import (
    MarketOrderRequest, TakeProfitRequest, StopLossRequest
)

from config import settings

class AlpacaBroker:
    def __init__(self):
        if not settings.api_key or not settings.secret_key:
            raise RuntimeError(
                "Missing ALPACA_API_KEY / ALPACA_SECRET_KEY. "
                "Copy .env.example to .env and add your Alpaca paper keys."
            )
        self.trading = TradingClient(
            settings.api_key, settings.secret_key, paper=settings.paper_trade
        )
        self.market = StockHistoricalDataClient(
            settings.api_key, settings.secret_key
        )

    def account(self):
        return self.trading.get_account()

    def positions(self):
        return self.trading.get_all_positions()

    def orders(self, limit=25):
        return self.trading.get_orders()[:limit]

    def position_for(self, symbol):
        try:
            return self.trading.get_open_position(symbol)
        except Exception:
            return None

    def is_market_open(self):
        return bool(self.trading.get_clock().is_open)

    def bars(self, symbol, limit=None):
        limit = limit or settings.lookback_bars
        start = datetime.now(timezone.utc) - timedelta(days=10)

        req = StockBarsRequest(
            symbol_or_symbols=symbol,
            timeframe=TimeFrame(settings.timeframe_minutes, TimeFrameUnit.Minute),
            start=start,
            limit=limit,
            feed=DataFeed.IEX,
        )
        result = self.market.get_stock_bars(req)
        df = result.df

        if isinstance(df.index, pd.MultiIndex):
            try:
                df = df.xs(symbol, level="symbol")
            except KeyError:
                return pd.DataFrame()

        return df.sort_index()

    def submit_bracket_buy(self, symbol, qty, price):
        stop = round(price * (1 - settings.stop_loss_pct), 2)
        target = round(price * (1 + settings.take_profit_pct), 2)

        request = MarketOrderRequest(
            symbol=symbol,
            qty=qty,
            side=OrderSide.BUY,
            type=OrderType.MARKET,
            time_in_force=TimeInForce.DAY,
            order_class="bracket",
            take_profit=TakeProfitRequest(limit_price=target),
            stop_loss=StopLossRequest(stop_price=stop),
        )
        return self.trading.submit_order(request)

    def submit_market_order(self, symbol, qty, side):
        order_side = OrderSide.BUY if side.upper() == "BUY" else OrderSide.SELL
        request = MarketOrderRequest(
            symbol=symbol,
            qty=qty,
            side=order_side,
            type=OrderType.MARKET,
            time_in_force=TimeInForce.DAY,
        )
        return self.trading.submit_order(request)

    def close_position(self, symbol):
        return self.trading.close_position(symbol)
