import pandas as pd
import streamlit as st
from streamlit_autorefresh import st_autorefresh
import plotly.graph_objects as go

from config import settings
from broker import AlpacaBroker
from engine import TradingEngine

st.set_page_config(page_title="AI Trading Bot", page_icon="🤖", layout="wide")
st.title("🤖 Real-Time AI Trading Bot")
st.caption(
    f"Mode: {'PAPER TRADING' if settings.paper_trade else 'LIVE TRADING'} · "
    "ML probability + technical features + risk controls"
)

if not settings.paper_trade:
    st.error("LIVE TRADING IS ENABLED. Orders can use real money.")

try:
    broker = AlpacaBroker()
    engine = TradingEngine(broker)
except Exception as exc:
    st.error(str(exc))
    st.stop()

st.sidebar.header("Controls")
auto_refresh = st.sidebar.checkbox("Auto-refresh dashboard", True)
refresh_seconds = st.sidebar.slider("Refresh seconds", 5, 120, 30)
symbol = st.sidebar.selectbox("Chart symbol", list(settings.symbols))

if auto_refresh:
    st_autorefresh(interval=refresh_seconds * 1000, key="dashboard_refresh")

account = broker.account()
equity = float(account.equity)
buying_power = float(account.buying_power)
last_equity = float(account.last_equity)
day_pnl = equity - last_equity
day_pct = (day_pnl / last_equity * 100) if last_equity else 0

c1, c2, c3, c4 = st.columns(4)
c1.metric("Equity", f"${equity:,.2f}")
c2.metric("Buying Power", f"${buying_power:,.2f}")
c3.metric("Today", f"${day_pnl:,.2f}", f"{day_pct:.2f}%")
c4.metric("Market", "OPEN" if broker.is_market_open() else "CLOSED")

st.subheader("AI Signals")
rows = []
for s in settings.symbols:
    try:
        rows.append(engine.analyze(s))
    except Exception as exc:
        rows.append({"symbol": s, "signal": "ERROR", "action": str(exc)})

signal_df = pd.DataFrame(rows)
if not signal_df.empty:
    cols = [
        c for c in [
            "symbol", "price", "signal", "prob_up",
            "confidence", "rsi", "volatility"
        ] if c in signal_df.columns
    ]
    st.dataframe(signal_df[cols], use_container_width=True, hide_index=True)

st.subheader(f"{symbol} Price")
bars = broker.bars(symbol, limit=250)
if not bars.empty:
    fig = go.Figure()
    fig.add_trace(go.Candlestick(
        x=bars.index,
        open=bars["open"],
        high=bars["high"],
        low=bars["low"],
        close=bars["close"],
        name=symbol,
    ))
    fig.update_layout(height=500, xaxis_rangeslider_visible=False)
    st.plotly_chart(fig, use_container_width=True)

st.subheader("Positions")
positions = broker.positions()
if positions:
    rows = [{
        "symbol": p.symbol,
        "qty": float(p.qty),
        "market_value": float(p.market_value),
        "avg_entry": float(p.avg_entry_price),
        "unrealized_pl": float(p.unrealized_pl),
    } for p in positions]
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
else:
    st.info("No open positions.")

st.subheader("Recent Orders")
try:
    orders = broker.orders(25)
    if orders:
        rows = [{
            "id": str(o.id),
            "symbol": o.symbol,
            "side": str(o.side),
            "status": str(o.status),
            "qty": float(o.qty) if o.qty else None,
            "submitted_at": o.submitted_at,
        } for o in orders]
        st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
    else:
        st.info("No orders found.")
except Exception as exc:
    st.warning(f"Could not load orders: {exc}")

st.subheader("Manual Test Order")
st.caption("Use this for paper testing. Check the confirmation before submitting.")
m1, m2, m3 = st.columns(3)
with m1:
    manual_side = st.selectbox("Side", ["BUY", "SELL"])
with m2:
    manual_qty = st.number_input("Quantity", min_value=0.01, value=1.0, step=0.01)
with m3:
    manual_confirm = st.checkbox("Confirm order")

if st.button("Submit Manual Order", type="primary"):
    if not manual_confirm:
        st.error("Check the confirmation box first.")
    else:
        try:
            result = broker.submit_market_order(symbol, manual_qty, manual_side)
            st.success(f"Submitted {manual_side} {manual_qty:g} {symbol}. Order ID: {result.id}")
        except Exception as exc:
            st.error(str(exc))

st.subheader("Automated Strategy")
st.write(
    "The engine trains a logistic-regression classifier on recent bars and "
    "combines the probability threshold with portfolio risk controls."
)
if st.button("Evaluate & Trade One Cycle"):
    st.dataframe(
        pd.DataFrame(engine.run_once()),
        use_container_width=True,
        hide_index=True,
    )

st.warning(
    "Starter algorithm only. Backtest and paper trade before considering live capital."
)
