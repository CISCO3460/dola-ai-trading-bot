# Real-Time AI Trading Bot — Alpaca + Streamlit

Paper-trading-first Python starter with Alpaca, Streamlit, risk controls, and a transparent ML signal model.

## Install
Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
source .venv/bin/activate

pip install -r requirements.txt
```

## Configure
Copy `.env.example` to `.env` and add your Alpaca PAPER credentials.

```text
ALPACA_API_KEY=your_paper_key
ALPACA_SECRET_KEY=your_paper_secret
ALPACA_PAPER_TRADE=true
```

Never put credentials in source control or chat.

## Dashboard
```bash
streamlit run app.py
```

## Autonomous loop
```bash
python trader.py
```

## Default risk settings
- Risk per trade: 0.5% of equity
- Maximum position: 20% of equity
- Maximum daily loss: 2%
- Stop loss: 1%
- Take profit: 2%
- Minimum BUY probability: 60%

The ML model predicts the probability that the next bar closes higher using recent OHLCV-derived features. It is a baseline research model, not a profit guarantee.

## Going live
Keep `ALPACA_PAPER_TRADE=true` until you have thoroughly backtested and paper-traded the system. To explicitly switch to live, set `ALPACA_PAPER_TRADE=false` and use live credentials.

This software is educational and experimental, not investment advice.
