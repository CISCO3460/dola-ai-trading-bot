from engine import TradingEngine

if __name__ == "__main__":
    engine = TradingEngine()
    print("AI trading loop started.")
    print("Paper trading:", engine.broker.trading._paper)
    engine.run_forever()
